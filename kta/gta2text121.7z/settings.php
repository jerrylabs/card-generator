<?php

///////////////////////////////////////////////////
// GTA2 Text Generator (v1.21), made by T.M. and Cuban-Pete
// Last update: 7.12.2011 (d.m.y)
// Forum topic: http://gtamp.com/forum/viewtopic.php?f=4&t=84
// License: Free for any use, with exceptions:
// 1) you must not claim you made this software.
// 2) you must give credit to the creators of this software.
// 3) this notice may not be removed or modified.
///////////////////////////////////////////////////

error_reporting(E_ALL ^ E_NOTICE);

$VERSION_STR = "1.2";
$BASE_URL = "epicgta2.omnitude.net/gta2text"; // for index.php forum image code url. (dont add slash at end!).

$MAX_WIDTH = 800; // output image max dimensions. (might get slightly larger for different fonts).
$MAX_HEIGHT = 400;
$BG_CAR_PAD = 10; // left/right padding in pixels, for car background (prevent drawing text too nearly to the edges).
$JPG_QUALITY = 90; // quality for JPG output type.

// select best image format:
$GIF_SUPPORTED = function_exists("imagegif");
$PNG_SUPPORTED = function_exists("imagepng");
$JPG_SUPPORTED = function_exists("imagejpeg");
if($GIF_SUPPORTED){
	$DEFAULT_IMGTYPE = "gif"; // smallest filesize and around 3x faster than PNG!
	$DEFAULT_IMGTYPE_HEADER = "gif";
}else if($PNG_SUPPORTED){
	$DEFAULT_IMGTYPE = "png";
	$DEFAULT_IMGTYPE_HEADER = "png";
}else if($JPG_SUPPORTED){
	$DEFAULT_IMGTYPE = "jpg";
	$DEFAULT_IMGTYPE_HEADER = "jpeg";
}else{
	die("No GD support for any image format output!\r\nGo install or update PHP GD library!");
}

$FONT_COLORS = array(array(0x3C3808, 0x8D7034, 0xCEC074, 0xAC9156), array(0x403524, 0x8C744E, 0xD4B584, 0xB39564), array(0x5B5B5B, 0xC7C7C7, 0xFFFFFF, 0xEBEBEB), array(0x3A4A5B, 0x7EA2C7, 0xE3F1FF, 0xA2D0FF), array(0x354454, 0x7495B7, 0xC6E1FA, 0x95BFEA), array(0x00375B, 0x0077C7, 0x41B1FF, 0x0099FF), array(0x5B5B27, 0xC7C756, 0xFFFFFF, 0xFFFF6E), array(0x5B3A1C, 0xC77F3E, 0xFFC48F, 0xFFA34F), array(0x54485B, 0xB89EC7, 0xFFFFFF, 0xECCBFF), array(0x5B2306, 0xC74D0E, 0xFF9053, 0xFF6312), array(0x235B09, 0x4CC713, 0xCCFFB5, 0x61FF18), array(0x5B4B27, 0xC7A455, 0xFFEECB, 0xFFD26D), array(0x002C19, 0x006037, 0x00A459, 0x007B46), array(0x141D5B, 0x2C40C7, 0x657FFF, 0x3852FF), array(0x4F1010, 0xAC2222, 0xF15555, 0xDD2C2C), array(0x5B4100, 0xC78E00, 0xFFDE97, 0xFFB600), array(0x1A175B, 0x3933C7, 0x7069FF, 0x4941FF), array(0x434343, 0x929292, 0xE9E9E9, 0xBBBBBB));

?>