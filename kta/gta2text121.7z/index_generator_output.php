<?php

///////////////////////////////////////////////////
// GTA2 Text Generator (v1.21), made by T.M. and Cuban-Pete
// Last update: 6.12.2011 (d.m.y)
// Forum topic: http://gtamp.com/forum/viewtopic.php?f=4&t=84
// License: Free for any use, with exceptions:
// 1) you must not claim you made this software.
// 2) you must give credit to the creators of this software.
// 3) this notice may not be removed or modified.
///////////////////////////////////////////////////

error_reporting(E_ALL ^ E_NOTICE);

if($text != ""){
	$text_encoded = urlencode($text);
	$text_zipped = urlencode(str_replace(array("+","/","="),array("_","-","."),base64_encode(gzdeflate($text,9))))."&z"; // z indicates zipped format.
	if(strlen($text_zipped) < strlen($text_encoded)){
		$text_encoded = $text_zipped; // use zipped format only if its smaller than normal format.
	}
	$list = array();
	if($font_style > 1) $list[] = "font=".$font_style;
	if($color_style) $list[] = "color=".$color_style;
	if($bg_style) $list[] = "bg=".$bg_style;
	if($shiny_style) $list[] = "shiny=".$shiny_style;
	$list[] = "text=".$text_encoded;
	$img_type_param = strtolower($imgtypelist[$imgtype_style]);
	if($img_type_param != $DEFAULT_IMGTYPE) $list[] = $img_type_param;

	$params = implode("&", $list);
	$img_url = "gta2text.php?$params";
	print"<br><img src=\"$img_url\" style=\"background-image:url('background.png'); padding:10px\">";
	print"<br><br>";
	print"Forum image code:<br><textarea name=\"test\" rows=\"5\" cols=\"40\">[img]http://{$BASE_URL}/{$img_url}[/img]</textarea><br>";
}

?>