<?php

///////////////////////////////////////////////////
// GTA2 Text Generator (v1.0), made by T.M. and Cuban-Pete
// Last update: 5.12.2011 (d.m.y)
// Forum topic: http://gtamp.com/forum/viewtopic.php?f=4&t=84
// License: Free for any use, with exceptions:
// 1) you must not claim you made this software.
// 2) you must give credit to the creators of this software.
// 3) this notice may not be removed or modified.
///////////////////////////////////////////////////

////////////////////////////////////////////////////
// NOTE:
// only useful if you change the main font images.
///////////////////////////////////////////////////
die(); // remove this line if you gonna use this, add it back when youre done (or delete this file).
///////////////////////////////////////////////////

$img = imagecreatefrompng("r2.png"); // note: r1.png wont work properly since it lacks the normal font shiniest color, modify it manually?

$count = 18;
$sx = 2;
$sy = 6;
$step = 9;

$xpos = $sx;

$colors = array();
for($u = 0; $u < $count; $u++){
	$color_border = imagecolorat($img, $xpos-1, $sy);
	$color_high = imagecolorat($img, $xpos, $sy);
	$color_high_mix = imagecolorat($img, $xpos+1, $sy);
	$color_main = imagecolorat($img, $xpos, $sy+1);
	$colors[] = array($color_border, $color_main, $color_high, $color_high_mix);
	$xpos += $step;
}
imagedestroy($img);

for($u = 0; $u < $count; $u++){
	// the purpose of this image loading is to load the ORIGINAL image with that shiny color too, so we can replace those pixels with all possible colors & save the image with different name.
	$img = imagecreatefrompng("gta2font_normal_c0.png"); // maybe should use gta2font_normal.png to fix errors mentioned above?
	imagesavealpha($img, true);
	$width = imagesx($img);
	$height = imagesy($img);

	for($y = 0; $y < $height; $y++){
		for($x = 0; $x < $width; $x++){
			$color = imagecolorat($img, $x, $y);
			if($color == $colors[0][0]){
				imagesetpixel($img, $x, $y, $colors[$u][0]);
			}else if($color == $colors[0][1]){
				imagesetpixel($img, $x, $y, $colors[$u][1]);
			}else if($color == $colors[0][2]){
				imagesetpixel($img, $x, $y, $colors[$u][2]);
			}else if($color == $colors[0][3]){
				imagesetpixel($img, $x, $y, $colors[$u][3]);
			}
		}
	}
	imagepng($img, "gta2font_normal_sc{$u}.png"); // change sc to c if using r1.png !
	imagedestroy($img);

	print"<a href=\"gta2font_normal_sc{$u}.png\">gta2font_normal_sc{$u}.png</a><br>";
}

?>