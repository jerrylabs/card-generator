<?php

///////////////////////////////////////////////////
// GTA2 Text Generator (v1.21), made by T.M. and Cuban-Pete
// Last update: 7.12.2011 (d.m.y)
// Forum topic: http://gtamp.com/forum/viewtopic.php?f=4&t=84
// License: Free for any use, with exceptions:
// 1) you must not claim you made this software.
// 2) you must give credit to the creators of this software.
// 3) this notice may not be removed or modified.
///////////////////////////////////////////////////

$start_time = microtime();

include("settings.php");

if(isset($_GET['all'])){
	error_reporting(E_ALL);
}else{
	error_reporting(E_ALL ^ E_NOTICE);
}

// select best input format:
if(function_exists("imagecreatefromgif")){
	$otype = "gif"; // fastest.
}else{
	$otype = "png";
}
$imagecreatefrom = "imagecreatefrom".$otype; // function name which is used to load the font images.

$imgtype = $DEFAULT_IMGTYPE; // set defaults, for image filename extension.
$headertype = $DEFAULT_IMGTYPE_HEADER; // for header. (dont change these!)

if(isset($_GET['gif'])){
	if($GIF_SUPPORTED){
		$imgtype = "gif";
		$headertype = "gif";
	}
}else if(isset($_GET['jpg'])){
	if($JPG_SUPPORTED){
		$imgtype = "jpg";
		$headertype = "jpeg"; // notice difference.
	}
}else if(isset($_GET['png'])){
	if($PNG_SUPPORTED){
		$imgtype = "png";
		$headertype = "png";
	}
}

if(!isset($_GET['noimg'])){
	if(!isset($_GET['debug'])){ // add "&debug" in end of url to see errors in the image and the debug info.
		$lastmod = filemtime("gta2text.php"); // get last modified time for this PHP file.
		$hash = crc32($_SERVER['QUERY_STRING'].$lastmod); // add lastmod in the hash so updated renderer gives different filenames too, also helps on caching.
		$savefilename = "gta2text_{$hash}.{$imgtype}"; // need unique filename that DOESNT change unless you change inputs/renderer. reason: images caching fails otherwise!
		header("Content-Type: image/{$headertype}");
		header("Content-Disposition: filename=\"{$savefilename}\""); // gives filename suggestion for user if he wants to save it.
		header("Last-Modified: ".gmdate("D, d M Y H:i:s", $lastmod)." GMT"); // images should be reloaded only when gta2text.php file was modified.
	}else{
		ob_start(); // for displaying time in debug mode, and not the image even when we generate it.
	}
}

$text = trim($_GET['text']);
$font_style = ((int)$_GET['font'])-1; // doesnt start from zero because we always need a font, font=0 would mean "no font".
$color_style = (int)$_GET['color'];
$bg_style = (int)$_GET['bg'];
$shiny_style = (bool)$_GET['shiny'];

// unzip input text if it was in zipped format:
if(isset($_GET['z'])){
	$text = @gzinflate(base64_decode(str_replace(array("_","-","."), array("+","/","="), $text)));
	if($text === false){ // note triple equal.
		$text = "(data error!)";
	}
}

if($text == ""){
	$text = "(text input is empty!)";
}

$allow_multiline = 1; // car/street doesnt allow multilines.
$transparent_image = 1; // generate transparent image by default. (optimized for car/street background options).

if($font_style == 1 && $bg_style){
	$bg_style = 0; // dont allow background for the large font type.
}

// load background images, if any selected:
if($bg_style == 1){ // car (dynamic)
	$allow_multiline = 0;
	$transparent_image = 0;
	$carbg_left = imagecreatefrompng("bg/carbg_left.png");
	$carbg_middle = imagecreatefrompng("bg/carbg_middle.png");
	$carbg_right = imagecreatefrompng("bg/carbg_right.png");
}else if($bg_style == 2){ // street (static)
	$allow_multiline = 0;
	$transparent_image = 0;
	$streetbg = imagecreatefrompng("bg/streetbg.png");
}

$shiny_prefix = ($shiny_style) ? "sc" : "c";

$font_types = array(0 => "normal", 1 => "large", 2 => "car", 3 => "street"); // do not modify, used for font filenames!
$max_fonts = count($font_types);

if($font_style < 0) $font_style = 0;
if($font_style > $max_fonts-1) $font_style = $max_fonts-1;

if($font_style != 0){
	$text = strtoupper($text); // only the normal font supports lowercased text.
	$color_style = 0; // only normal font can have colors.
}

if(!is_valid_color_code($color_style)){
	$color_style = 0;
}

// load font data array:
$typestr = $font_types[$font_style];
$poswidth = include("fonts/{$typestr}/data_{$typestr}.php"); // returns array

// load font image (and get $font_height at same time):
$fnt = array(); // hold our fonts (for colored fonts need array).
if($font_style == 0 && is_valid_color_code($color_style)){
	choose_font_color($color_style); // load the initial font with correct color.
}else{
	basic_font_loading("fonts/{$typestr}/gta2font_{$typestr}.{$otype}", $color_style); // color_style=0 so it adds font to first item in array.
}

function is_valid_color_code($color_code){
	global $FONT_COLORS;
	return ($color_code >= 0 && $color_code < count($FONT_COLORS));
}

function basic_font_loading($filename, $color_code){
	global $font_height, $fnt, $imagecreatefrom;
	$fnt[$color_code] = $imagecreatefrom($filename);
	$font_height = imagesy($fnt[$color_code]); // always the same size as these font images height.
	imagealphablending($fnt[$color_code], true);
}

// load normal font (by color code) only when its hasnt been loaded yet:
function choose_font_color($color_code){
	global $fnt, $font_style, $font_height, $shiny_prefix, $typestr, $otype; // $font_height must be global here too for basic_font_loading() function to work.
	if($font_style == 0 && is_valid_color_code($color_code)){
		if(!array_key_exists($color_code, $fnt)){
			basic_font_loading("fonts/{$typestr}/{$shiny_prefix}/gta2font_{$typestr}_{$shiny_prefix}{$color_code}.{$otype}", $color_code);
		}
	}
}

// note: globals!
function render_gta2text($start_x, $start_y, $str, $render_it = true){
	global $font_height, $im, $fnt, $poswidth, $color_style, $font_style, $MAX_WIDTH, $MAX_HEIGHT, $allow_multiline, $otype;
	$len = strlen($str);
	$width = 0; // max image width
	$xpos = 0; // currently looped chars pixel positions,
	$ypos = 0;
	$color_code = $color_style; // set to initial color (chosen from the list).
	choose_font_color($color_code); // this will load font in case not loaded yet.

	for($p = 0; $p < $len; $p++){
		$val = ord($str[$p]); // get char numeric value.
		$charwidth = $poswidth[$val*2+1];
		// handle newlines:
		if($allow_multiline){
			if($str[$p] == "\n"){
				$ypos += $font_height;
				$xpos = 0;
			}
			// force newlines for too wide images:
			if($xpos > $MAX_WIDTH){
				$ypos += $font_height;
				$xpos = 0;
			}
			if($ypos > $MAX_HEIGHT){
				$ypos -= $font_height; // we add it back later
				break; // stop drawing after too many lines reached.
			}
		}else{
			if($xpos > $MAX_WIDTH){
				break; // stop drawing for one-liner images.
			}
		}
		// handle colors (only for normal font):
		if($str[$p] == '['){
			$step = 0;
			if($str[$p+2] == ']'){ // "[5]"
				$tempcode = substr($str, $p+1, 1);
				$step = 2;
			}else if($str[$p+3] == ']'){ // "[15]"
				$tempcode = substr($str, $p+1, 2);
				$step = 3;
			}
			if($step > 0){
				// dont treat any string as a number; convert to integer only if its numeric,
				if(is_numeric($tempcode)){
					// dont change font for other than normal font:
					if($font_style == 0){
						$tempcode = (int)$tempcode-1; // -1 because user gives 1-18, but our indexes are 0-17.
						// change the color only if it was valid:
						if(is_valid_color_code($tempcode)){
							$color_code = $tempcode;
							choose_font_color($color_code); // load the font color if not loaded yet.
						}
					}
					$p += $step; // skip rest of the color code string. ($p++ skips one more at "continue").
					continue; // skip rendering color codes.
				}
			}
		}
	
		if($charwidth == 0){
			continue; // skip chars that cant be rendered.
		}
		if($render_it){
			$charpos = $poswidth[$val*2];
			imagecopy($im, $fnt[$color_code], $xpos+$start_x, $ypos+$start_y, $charpos, 0, $charwidth, $font_height);
		}
		$xpos += $charwidth;

		// find max image width (added $charwidth previously):
		if($xpos > $width){
			$width = $xpos;
		}
	}
	return array($width, $ypos+$font_height); // add $font_height here because there isnt last "\n" char.
}

$blocks_needed = 0; // for background renderer.
$start_x = 0; // centered text start positions
$start_y = 0;

// calculate resulting image size:
list($width, $height) = render_gta2text(0, 0, $text, false); // false = dont render, just get sizes, xy=zero for getting correct text width.

if($width == 0){
	$text = "(no visible text to render!)";
	list($width, $height) = render_gta2text(0, 0, $text, false); 
}

// re-calculate the resulting image sizes for background image options:
if($bg_style){
	$orig_text_width = $width;
	$orig_text_height = $height;
	if($bg_style == 1){
		$bg_height = imagesy($carbg_left);
		$min_bg_size = imagesx($carbg_left)+imagesx($carbg_right);
		$width_padded = $width+($BG_CAR_PAD*2); // need at least this wide image, we dont want to draw text too near to the edges.
		$width_overflow = $width_padded-$min_bg_size; // remaining width for the middle pieces.
		// calculate how many middle blocks we need to render:
		if($width_overflow > 0){
			$blocks_needed = ceil($width_overflow/imagesx($carbg_middle));
		}
		// fix the output image width/height:
		$width = (imagesx($carbg_middle)*$blocks_needed)+$min_bg_size;
		$height = $bg_height; // always max the bg height!
	}else if($bg_style == 2){
		$bg_height = imagesy($streetbg);
		$min_bg_size = imagesx($streetbg);
		// fix the output image width/height:
		$width = $min_bg_size;
		$height = $bg_height; // always max the bg height!
	}
	$start_x = round($width/2)-round($orig_text_width/2); // calculate the centered text starting position.
	$start_y = round($bg_height/2)-round($orig_text_height/2);
}

///////////////////////////////////
//
//         render image
//
///////////////////////////////////

$im = imagecreatetruecolor($width, $height); // even the paletted images should use truecolor.
// might optimize filesize when we dont need alpha:
if($transparent_image){
	imagealphablending($im, false);
	imagesavealpha($im, true);
}else{
	imagealphablending($im, true);
	imagesavealpha($im, false);
}

// fill background with transparent and white color:
// white is also all fonts background, which means better compression and cleaner 
// look and support for programs that fails displaying transparent PNG correctly.
if($transparent_image){
	$bgcolor = imagecolorallocatealpha($im, 255,255,255, 127); // 127 = full transparency.
	// gif needs special handling for transparency:
	if($imgtype == "gif"){
		imagecolortransparent($im, $bgcolor); // mark the color+alpha as transparent. (must use imagecolorallocatealpha!)
	}
	imagefilledrectangle($im, 0, 0, $width, $height, $bgcolor);
}

// render background images, if any selected:
if($bg_style == 1){ // car
	// render left/right pieces:
	imagecopy($im,$carbg_left, 0,0, 0,0, imagesx($carbg_left),imagesy($carbg_left));
	imagecopy($im,$carbg_right, $width-imagesx($carbg_right),0, 0,0, imagesx($carbg_right),imagesy($carbg_right));
	// render middle pieces:
	$xpos = imagesx($carbg_left);
	for($p = 0; $p < $blocks_needed; $p++){
		imagecopy($im,$carbg_middle, $xpos,0, 0,0, imagesx($carbg_middle),imagesy($carbg_middle));
		$xpos += imagesx($carbg_middle);
	}
}else if($bg_style == 2){ // street
	imagecopy($im,$streetbg, 0,0, 0,0, imagesx($streetbg),imagesy($streetbg));
}

render_gta2text($start_x, $start_y, $text);

$end_time = microtime();

if(!isset($_GET['noimg'])){
	// output selected imagetype:
	if($imgtype == "png"){
		imagepng($im);
	}else if($imgtype == "jpg"){
		imagejpeg($im, NULL, $JPG_QUALITY);
	}else if($imgtype == "gif"){
		imagegif($im);
	}
}

$end_time_generate = microtime();

if(isset($_GET['debug'])){
	$filesize = ob_get_length();
	if(!isset($_GET['noimg'])){
		ob_clean(); // destroy the PNG output for debug. (we still like to know how fast it generates it).
	}
}

$start_time_free = microtime();

// free resources:
imagedestroy($im);
foreach($fnt as $res){
	imagedestroy($res);
}
// free possible loaded backgrounds:
if($bg_style == 1){
	imagedestroy($carbg_left);
	imagedestroy($carbg_middle);
	imagedestroy($carbg_right);
}else if($bg_style == 2){
	imagedestroy($streetbg);
}

$end_time_free = microtime();

function get_time_diff($start, $end){
	$s = explode(" ", $start); // input = microtime()
	$e = explode(" ", $end);
	return (($e[0]+$e[1])-($s[0]+$s[1]))*1000; // output in milliseconds
}

if(isset($_GET['debug'])){
	$time_render = get_time_diff($start_time, $end_time);
	$time_img = get_time_diff($end_time, $end_time_generate);
	$time_free = get_time_diff($start_time_free, $end_time_free);
	$time_total = get_time_diff($start_time, $end_time_free);
	print"<pre>";
	printf("Output image filesize: %.1f KB (%d bytes)\r\n", $filesize/1000, $filesize);
	print"\r\n";
	print"Time taken to:\r\n";
	printf("Render font: %.1f ms\r\n", $time_render);
	printf("Create %s: %.1f ms\r\n", strtoupper($imgtype), $time_img);
	printf("Free resources: %.1f ms\r\n", $time_free);
	printf("Total: %.1f ms\r\n", $time_total);
	if(!isset($_GET['noimg'])){
		ob_end_flush();
	}
}

die(); // ensure no more text can be outputted (if source copied from a webpage, there might be whitespace after '?>' code.

?>