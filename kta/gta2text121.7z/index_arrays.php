<?php

///////////////////////////////////////////////////
// GTA2 Text Generator (v1.21), made by T.M. and Cuban-Pete
// Last update: 7.12.2011 (d.m.y)
// Forum topic: http://gtamp.com/forum/viewtopic.php?f=4&t=84
// License: Free for any use, with exceptions:
// 1) you must not claim you made this software.
// 2) you must give credit to the creators of this software.
// 3) this notice may not be removed or modified.
///////////////////////////////////////////////////

error_reporting(E_ALL ^ E_NOTICE);

// these arrays may be modified, but dont change the array keys, or order of the array if keys arent visible!:
$sizes = array(1 => "Normal", 2 => "Large", 3 => "Car", 4 => "Street");
$backgrounds = array(0 => "None", 1 => "Car", 2 => "Street");
$shinylist = array("No", "Yes");
$imgtypelist = array("PNG", "GIF", "JPG");

$colors = array();
foreach($FONT_COLORS as $key => $val){
	$colors[$key] = (string)($key+1);
}

?>