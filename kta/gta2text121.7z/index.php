<?php

///////////////////////////////////////////////////
// GTA2 Text Generator (v1.21), made by T.M. and Cuban-Pete
// Last update: 7.12.2011 (d.m.y)
// Forum topic: http://gtamp.com/forum/viewtopic.php?f=4&t=84
// License: Free for any use, with exceptions:
// 1) you must not claim you made this software.
// 2) you must give credit to the creators of this software.
// 3) this notice may not be removed or modified.
///////////////////////////////////////////////////

error_reporting(E_ALL ^ E_NOTICE);

include("settings.php");
include("index_html_header.php");

$text = trim($_GET['text']);
$font_style = (int)$_GET['font'];
$color_style = (int)$_GET['color'];
$bg_style = (int)$_GET['bg'];
$shiny_style = (bool)$_GET['shiny'];

// allow decoding the encoded crap in the index page as well:
if(isset($_GET['z'])){
	$text = @gzinflate(base64_decode(str_replace(array("_","-","."), array("+","/","="), $text)));
	if($text === false){
		$text = "(data error!)";
	}
}

include("index_arrays.php");

// get default imagetype index:
if(!isset($_GET['imgtype'])){
	foreach($imgtypelist as $key => $val){
		if(strtolower($val) == $DEFAULT_IMGTYPE){
			$imgtype_style = $key;
			break;
		}
	}
}else{
	$imgtype_style = (int)$_GET['imgtype'];
}

if($font_style == 0) $font_style = 1;

function list_option($arr, $name, $current, $color_opts = ""){
	$use_colors = is_array($color_opts);
	$style = "";
	$out = "<select name=\"$name\">";
	foreach($arr as $key => $value){
		if($use_colors){
			// ref: array($color_border, $color_main, $color_high, $color_high_mix)
			$style = sprintf(" style=\"background-color:#%06X; color:#%06X\"", $color_opts[$key][1], $color_opts[$key][2]);
		}
		$sel = ($key == $current) ? " selected" : "";
		$out .= "<option value=\"$key\"{$style}{$sel}>$value</option>";
	}
	$out .= "</select>";
	return $out;
}

include("index_form.php");
include("index_generator_output.php");

print"<br><br><hr color=\"#DDDDDD\"><br><center>";
print" ".date("Y")." | Version {$VERSION_STR} ";
print"<br><br>";

?></body></html>