<?php

///////////////////////////////////////////////////
// GTA2 Text Generator (v1.21), made by T.M. and Cuban-Pete
// Last update: 7.12.2011 (d.m.y)
// Forum topic: http://gtamp.com/forum/viewtopic.php?f=4&t=84
// License: Free for any use, with exceptions:
// 1) you must not claim you made this software.
// 2) you must give credit to the creators of this software.
// 3) this notice may not be removed or modified.
///////////////////////////////////////////////////

error_reporting(E_ALL ^ E_NOTICE);

print"<img src=\"title.gif\"><br><br>";
print"<form method=\"get\" action=\"\">";
print" Background: ".list_option($backgrounds, "bg", $bg_style);
print" Font: ".list_option($sizes, "font", $font_style);
print" Color: ".list_option($colors, "color", $color_style, $FONT_COLORS);
print" Shiny: ".list_option($shinylist, "shiny", $shiny_style);
print" Type: ".list_option($imgtypelist, "imgtype", $imgtype_style);
print"<br><table style=\"font:12px verdana\"><tr><td valign=\"top\"><textarea name=\"text\" rows=\"8\" cols=\"64\">".htmlspecialchars($text)."</textarea></td><td valign=\"top\">";
print"<b>Notes:</b><br>";
print"- Color codes can be used: <a href=\"?font=1&color=0&shiny=1&bg=0&text=[5]This+[7]is+[1]colored+[18]text!\">[5]This [7]is [1]colored [18]text!</a><br>";
print"- Colors and shinyness option works only for the normal font.<br>";
print"- Image max size is {$MAX_WIDTH}x{$MAX_HEIGHT}<br>";
print"- Background image only works with one line and not with the large font.<br>";
print"- ".strtoupper($DEFAULT_IMGTYPE)." is default image format, and it's highly recommended to be used!<br>";
print"<br>- <a href=\"?font=1&color=0&shiny=0&bg=0&text=[1]1+-+Normal%0D%0A[2]2+-+Light+Brown%0D%0A[3]3+-+White+%28grey%29%0D%0A[4]4+-+Bright+Blue%0D%0A[5]5+-+Dark+Blue%0D%0A[6]6+-+Veteran+%28forum%29%0D%0A[7]7+-+VIP+%28forum%29%0D%0A[8]8+-+Administrator+%28forum%29%0D%0A[9]9+-+Elvis+Mafia%0D%0A[10]10+-+Krishna%0D%0A[11]11+-+Loonies%0D%0A[12]12+-+Mad+Island+Mafia%0D%0A[13]13+-+Prison+Mafia%0D%0A[14]14+-+Redneck%0D%0A[15]15+-+Russian+Mafia%0D%0A[16]16+-+Scientists%0D%0A[17]17+-+Yakuza%0D%0A[18]18+-+Zaibatsu\">See all colors!</a><br>";
print"</td></tr></table><br>";
print"<input type=\"submit\" value=\"Generate image\">";
print"</form>";

?>