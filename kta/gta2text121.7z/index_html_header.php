<?php

///////////////////////////////////////////////////
// GTA2 Text Generator (v1.21), made by T.M. and Cuban-Pete
// Last update: 7.12.2011 (d.m.y)
// Forum topic: http://gtamp.com/forum/viewtopic.php?f=4&t=84
// License: Free for any use, with exceptions:
// 1) you must not claim you made this software.
// 2) you must give credit to the creators of this software.
// 3) this notice may not be removed or modified.
///////////////////////////////////////////////////

?><html>
<head>
	<title>GTA2 Text Generator, by T.M. and Cuban-Pete</title>
	<link rel="shortcut icon" href="favicon.ico">
</head>
<body style="font:12px verdana">