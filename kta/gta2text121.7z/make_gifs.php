<?php

///////////////////////////////////////////////////
// GTA2 Text Generator (v1.2), made by T.M. and Cuban-Pete
// Last update: 6.12.2011 (d.m.y)
// Forum topic: http://gtamp.com/forum/viewtopic.php?f=4&t=84
// License: Free for any use, with exceptions:
// 1) you must not claim you made this software.
// 2) you must give credit to the creators of this software.
// 3) this notice may not be removed or modified.
///////////////////////////////////////////////////

error_reporting(E_ALL ^ E_NOTICE);

die("not in use");

function png_to_gif($filename, $savefilename = ""){
	if($savefilename == ""){ // autogenerate filename:
		$savefilename = substr($filename, 0, -4).".gif";
	}
	$im = imagecreatefrompng($filename);
	imagealphablending($im, true);

	// probably no need to generate new image, but did anyways just to be sure (dunno anymore if it helped).
	$out = imagecreatetruecolor(imagesx($im),imagesy($im));
	imagealphablending($out, false);
	imagesavealpha($out, true);

	$bgcolor = imagecolorallocatealpha($out, 255,255,255, 127); // 127 = full transparency.
	imagecolortransparent($out, $bgcolor); // mark the color+alpha as transparent. (must use imagecolorallocatealpha!)
	imagefilledrectangle($out, 0, 0, imagesx($out),imagesy($out), $bgcolor);
	imagecopy($out,$im, 0,0, 0,0, imagesx($im),imagesy($im));

	imagegif($out, $savefilename);
	imagedestroy($im);
	imagedestroy($out);

	print"<a href=\"$savefilename\">$savefilename</a><br>";
}

png_to_gif("fonts/car/gta2font_car.png");
png_to_gif("fonts/street/gta2font_street.png");
png_to_gif("fonts/large/gta2font_large.png");

for($u = 0; $u < 18; $u++){
	png_to_gif("fonts/normal/c/gta2font_normal_c{$u}.png");
	png_to_gif("fonts/normal/sc/gta2font_normal_sc{$u}.png");
}

?>